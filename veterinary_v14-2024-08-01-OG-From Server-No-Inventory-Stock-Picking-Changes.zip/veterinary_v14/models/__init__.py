# -*- coding: utf-8 -*-
# https://www.odoo.com/documentation/14.0/howtos/backend.html

from . import appointment
from . import configuration
from . import customer
from . import vaccination
from . import hospitalisation